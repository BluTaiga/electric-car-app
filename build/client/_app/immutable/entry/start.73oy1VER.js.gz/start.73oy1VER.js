import{a as t}from"../chunks/entry.D9C0CAoD.js";export{t as start};
